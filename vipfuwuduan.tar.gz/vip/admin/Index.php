<?php
namespace app\vip\admin;
/**
 * Created by PhpStorm.
 * User: burnell
 * Date: 2019/7/4
 * Time: 14:30
 */
use app\admin\controller\Admin;
use app\common\builder\ZBuilder;
use PhpOffice\PhpSpreadsheet\Reader\Xls;
use think\Db;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\IOFactory;

class Index extends Admin{
    private static $new_vip = [];//如果存在新会员 则存入数组
    //三打哈vip规则
    public function index(){
        $map = $this->getMap();
        $data = Db::name('vip_rule')->where($map)->order('vip_id asc')->paginate();
        return ZBuilder::make('table')
            ->setTableName('vip_rule')
            ->hideCheckbox()
            ->addColumns([
                ['vip_id','会员等级','callback',function($val){
                    if($val == 0){
                        $data = '普通会员';
                    }else{
                        $data = 'vip_'.$val;
                    }
                    return $data;
                }],
                ['bet_amt','有效投注量','callback',function($val){
                    if(floatval($val) == 0){
                        $data = 0;
                    }else if(floatval($val) > 0 && floatval($val) < 100000000){
                        $data = (floatval($val)/10000).'万+';
                    }else{
                        $data = (floatval($val)/100000000).'亿+';
                    }
                    return $data;
                }],
                ['lottery_money','晋级彩金'],
                ['birthday_money','生日礼金'],
                ['holiday_money','节日礼金'],
                ['vip_domain','专属域名','callback',function($val){return $val?'有':'无';}],
                ['cus_sm','1v1客服经理','callback',function($val){return $val?'有':'无';}],
                ['created_at','创建时间'],
                ['updated_at','更新时间'],
                ['right_button', '操作', 'btn']
            ])
            ->setColumnWidth([
                'vip_id'  => 70,
                'bet_amt' => 70,
                'lottery_money' => 80,
                'birthday_money' => 80,
                'holiday_money' => 80,
                'vip_domain' => 60,
                'cus_sm' => 60,
            ])
            ->addRightButton('edit', ['href' => url('vip_edit', ['id' => '__vip_id__'])])
            ->setRowList($data) // 设置表格数据
            ->fetch();
    }

    //会员规则修改
    public function vip_edit($id = ''){
        if($id || $id == 0){
            if($_POST){
                $bet = input('post.bet');
                $lottery_money = input('post.lottery_money');
                $birthday_money = input('post.birthday_money');
                $holiday_money = input('post.holiday_money');
                $vip_domain = input('post.vip_domain');
                $cus_sm = input('post.cus_sm');
                $data = [
                    'bet_amt' => $bet,
                    'lottery_money' => $lottery_money,
                    'birthday_money' => $birthday_money,
                    'holiday_money' => $holiday_money,
                    'vip_domain' => $vip_domain,
                    'cus_sm' => $cus_sm,
                    'updated_at' => date('Y-m-d H:i:s')
                ];
                Db::name('vip_rule')->where('vip_id',$id)->update($data);
                $this->success('编辑成功','vip/Index/index');
            }else{
                $data = Db::name('vip_rule')->where('vip_id',$id)->find();
                return ZBuilder::make('form')
                    ->addText('bet', '有效投注量','',$data['bet_amt'])
                    ->addText('lottery_money', '晋级彩金','',$data['lottery_money'])
                    ->addText('birthday_money', '生日礼金','',$data['birthday_money'])
                    ->addText('holiday_money', '节日礼金','',$data['holiday_money'])
                    ->addRadio('vip_domain', '专属域名', '', ['0' => '无', '1' => '有'], $data['vip_domain'])
                    ->addRadio('cus_sm', '1v1客服经理', '', ['0' => '无', '1' => '有'], $data['cus_sm'])
                    ->fetch();
            }
        }else{
            $this->error('系统错误，请刷新后再试！');
        }
    }

    //三打哈会员列表
    public function vip_user(){
        //历史记录
        $money = [
            'title' => '晋级彩金',
            'icon'  => 'fa fa-fw fa-clock-o',
            'href'  => url('payout_history',['id'=>'__id__','grade'=>'__bet_anum__','name'=>'__username__'])
        ];

        $map = $this->getMap();
        $data = Db::name('vip_info')->where($map)->paginate();
        return ZBuilder::make('table')
            ->hideCheckbox()
            ->setSearch(['username' => '会员账号']) // 设置搜索参数
            ->addColumns([
                ['id','ID'],
                ['username','会员账户'],
                ['bet_anum','投注总量','callback',function($val){
                    return $val/100;
                }],
                ['grade','当前等级','callback',function($all){
                    $grade = $this->vip_grade($all['bet_anum']);
                    if($grade == 0){
                        return '普通会员';
                    }else{
                        return 'vip_'.$grade;
                    }
                },'__data__'],
                ['updated_at','更新时间'],
                ['right_button', '操作', 'btn']
            ])
            ->addRightButton('custom',$money,true)
            ->setRowList($data) // 设置表格数据
            ->fetch();
    }

    //晋级彩金派彩历史
    public function payout_history($id = '',$grade = 0 ,$name){
        $Columns = [
            ['v_id','会员账号','callback',function($val,$key,$name){
                return $name;
            },'__data__',$name],
            ['grade','会员等级','callback',function($val){return 'vip_'.$val;}],
            ['money','派彩金额'],
            ['time','派彩时间','datetime','','Y-m-d H:i:s'],
            ['status','派彩状态','status','',['未派彩', '已派彩']],
            ['right_button', '操作', 'btn']
        ];


        if($id){
            //派彩按钮
            $payout = [
                'title' => '派彩',
                'icon'  => 'fa fa-fw fa-cny',
                'href'  => url('payout',['id'=>$id,'pid'=>'__id__','money'=>'__money__','grade'=>'__grade__','bet'=>$grade,'name'=>$name])
            ];

            $map = $this->getMap();
            $data = Db::name('vip_history')->where($map)->where('v_id',$id)->order('id desc')->paginate();
            $grade = $this->vip_grade($grade);
            if(count($data)>0){
                if($grade == $data[0]['grade']){
                    return ZBuilder::make('table')
                        ->hideCheckbox()
                        ->addColumns($Columns)
                        ->addRightButton('custom',$payout)
                        ->setRowList($data) // 设置表格数据
                        ->fetch();
                }else{
                    $money = Db::name('vip_rule')->where('vip_id',$grade)->field('lottery_money')->find();
                    $first = [
                        'id' => -1,
                        'v_id'  => '',
                        'grade' => $grade,
                        'money' => $money['lottery_money'],
                        'time'  => '',
                        'status' => 0
                    ];
                    $data = $data->toArray();

                    array_unshift($data['data'],$first);
                    return ZBuilder::make('table')
                        ->hideCheckbox()
                        ->addColumns($Columns)
                        ->addRightButton('custom',$payout)
                        ->setRowList($data['data']) // 设置表格数据
                        ->fetch();
                }
            }else{
                $money = Db::name('vip_rule')->where('vip_id',$grade)->field('lottery_money')->find();
                $first[] = [
                    'id' => -1,
                    'v_id'  => '',
                    'grade' => $grade,
                    'money' => $money['lottery_money'],
                    'time'  => '',
                    'status' => 0
                ];
                return ZBuilder::make('table')
                    ->hideCheckbox()
                    ->addColumns($Columns)
                    ->addRightButton('custom',$payout)
                    ->setRowList($first) // 设置表格数据
                    ->fetch();
            }
        }else{
            $this->error('系统错误，请刷新后再试！');
        }
    }

    //派彩操作
    public function payout($id = '',$pid = '',$money = '',$grade ='',$bet,$name){
        if($id){
            //如果$pid == -1 则直接进行派彩操作  不等于-1 不能进行派彩操作
            if($pid == -1 && $grade > 0){
                $data = [
                    'v_id'  => $id,
                    'grade' => $grade,
                    'time'  => time(),
                    'money' => $money,
                    'status'=> 1
                ];
                Db::name('vip_history')->insert($data);
                $this->success('派彩成功','http://127.0.0.50/admin.php/vip/index/payout_history/id/'.$id.'/grade/'.$bet.'/name/'.$name.'.html?_pop=1');
            }else{
                $this->error('已派彩或等级为普通会员，无需派彩！');
            }
        }else{
            $this->error('系统错误，请刷新后再试！');
        }
    }

    //会员等级判断
    private function vip_grade($bet){
        $new = [];
        $grade = 0;
        $vip_grade = Db::name('vip_rule')->field('bet_amt,vip_id')->select();
        $bet = floatval($bet/100);
        foreach($vip_grade as $v){
            $new[$v['vip_id']] = $v['bet_amt'];
        }
        ksort($new);
        for($i = 0;$i<count($vip_grade);$i++){
            if($i == 0){
                if($bet <= $new[$i]){
                    $grade = $i;
                }
            }else if($i == count($vip_grade)-1){
                if($bet >= $new[$i]){
                    $grade = $i;
                }
            }else{
                if($bet<= $new[$i+1] && $bet> $new[$i]){
                    $grade = $i;
                }
            }
        }
        return $grade;
    }

    //文件上传列表
    public function vip_file(){
        //删除文件操作  并清除该文件所上传的数据
        $btn_delete = [
            'title' => '删除文件',
            'icon'  => 'fa fa-fw fa-remove',
            'class' => 'btn btn-xs btn-default ajax-get confirm',
            'href'  => url('delete_file', ['name' => '__file_name__','time' => '__created_at__']),
            'data-title' => '真的要删除吗？',
            'data-tips' => '删除该文件会恢复该文件所上传的数据，请谨慎删除！'
        ];

        //上传文件按钮
        $btn_upload = [
            'title' => '文件上传',
            'icon'  => 'fa fa-fw fa-cloud-upload',
            'href'  => url('upload')
        ];

        //下载文件按钮
        $btn_download = [
            'title' => '文件下载',
            'icon'  => 'fa fa-fw fa-cloud-download',
            'href'  => url('download',['name'=>'__file_name__'])
        ];
        $map = $this->getMap();
        $data = Db::name('vip_files')->where($map)->order('id desc')->paginate();
        return ZBuilder::make('table')
            ->hideCheckbox()
            ->setSearch(['file_name' => '文件名称']) // 设置搜索参数
            ->addColumns([
                ['id','ID'],
                ['file_name','文件名称'],
                ['created_at','上传时间'],
                ['right_button', '操作', 'btn']
            ])
            ->setColumnWidth([
                'id'  => 50,
                'right_button' => 30,
            ])
            ->addTopButton('custom', $btn_upload) // 添加上传按钮
            ->addRightButton('custom',$btn_delete) // 删除
            ->addRightButton('custom',$btn_download) // 添加下载按钮
            ->setRowList($data) // 设置表格数据
            ->fetch();
    }

    //文件删除操作
    public function delete_file($name ,$time){
        $all = [];
        $path = Db::name('admin_attachment')->where('name',$name)->field('path')->find();
        //获取文件数据
        $data = $this->get_xml('/'.$path['path']);
        $all_vip = Db::name('vip_info')->field('username,bet_anum')->select();
        //循环处理数据  以键值对的形式存储
        foreach($all_vip as $v){
            $all[$v['username']] = $v['bet_anum'];
        }
        //总投注量减去该文件的投注量
        foreach($data as $k => $v){
            $update_data = [
                'username'   => $k,
                'bet_anum'   => floatval($all[$k]) - floatval($v*100),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            Db::name('vip_info')->where('username',$k)->update($update_data);
        }
        //删除文件记录
        Db::name('vip_files')->where('file_name',$name)->delete();
//        //删除有效投注里面的记录
//        $one_time = date('Y-m-d H:i:s',strtotime($time)+120);
//        Db::name('vip_bet')->where('created_at','<=',$one_time)->where('created_at','>=',$time)->delete();
        $this->success('删除成功','vip/Index/vip_file');
    }

    //文件下载操作
    public function download($name = ''){
        if($name){
//            $data = Db::name('admin_attachment')->where('name',$name)->field('path')->find();
//            $fileName = ROOT_PATH.'public/'.$data['path']; //得到文件名
//            header( "Content-Disposition:  attachment;  filename=".$name); //告诉浏览器通过附件形式来处理文件
//            header('Content-Length: ' . filesize($fileName)); //下载文件大小
//            readfile($fileName);  //读取文件内容

            $filename = Db::name('admin_attachment')->where('name',$name)->field('path')->find();
            $file  =  fopen($filename['path'], "rb");
            Header( "Content-type:  application/octet-stream ");
            Header( "Accept-Ranges:  bytes ");
            Header( "Content-Disposition:  attachment;  filename= ".$name);
            $contents = "";
            while (!feof($file)) {
                $contents .= fread($file, 8192);
            }
            echo $contents;
            fclose($file);
        }else{
            $this->error('系统错误，请稍后再试');
        }
    }

    //文件上传操作
    public function upload(){
        if($_POST){
            if(!input('post.file'))
                $this->error('请上传文件！');
            //上传成功后需要处理的数据
            $name = get_file_name(input('post.file'));
            $path = get_file_path(input('post.file'));
            $data = $this->get_xml($path);
            //防止多次上传
            if(Db::name('vip_files')->where('file_name',$name)->count() > 0)
                $this->error('文件名重复，请勿重复上传！');
            //上传时记录日志
            Db::name('vip_files')->insert(['file_name'=>$name,'created_at'=>date('Y-m-d H:i:s')]);
            //处理数据
            foreach($data as $k=>$v){
                //每次循环更新数据 并添加进数组
                $this->vip_data($k,$v);
            }
            //再次更新上传时间
            Db::name('vip_files')->where('file_name',$name)->update(['updated_at'=>date('Y-m-d H:i:s')]);
            //添加新的会员
            Db::name('vip_info')->insertAll(self::$new_vip);
            //清除数组
            self::$new_vip = [];
            $this->success('上传成功','vip/Index/vip_file');
        }else{
            return ZBuilder::make('form')
                ->addFile('file', '文件')
                ->fetch();
        }
    }

    //处理数据
    private function vip_data($name ,$bet){
        //先进行判断该用户是否存在
        $count = Db::name('vip_info')->where('username',$name)->find();
        if(count($count)>0){
            //存在则进行更新判断  先进行等级查询
            $new_all_bet = floatval($count['bet_anum']) + floatval($bet*100);
            $grade = $this->vip_grade($new_all_bet);
            $history = json_decode($count['vip_grade_time'],1);
            if(count($history) == ($grade+1)){
                //没有升级
                $data = [
                    'bet_anum'   => $new_all_bet,
                    'updated_at' => date('Y-m-d H:i:s')
                ];
            }else{
                $history[] = ['vip_grade'=>$grade,'grade_time'=>time()];
                //升级
                $data = [
                    'bet_anum'       => $new_all_bet,
                    'updated_at'     => date('Y-m-d H:i:s'),
                    'vip_grade_time' => json_encode($history)
                ];

            }
            Db::name('vip_info')->where('username',$name)->update($data);
        }else{
            //不存在则先将用户存入数组中
            self::$new_vip[] = [
                'username' => $name,
                'bet_anum' => $bet
            ];
        }

    }

    //读取上传文档数据
    private function get_xml($file)
    {
        $data = [];
        $filename = ROOT_PATH . 'public' . $file;
        @$xml = simplexml_load_file($filename);
        $table = $xml->Worksheet->Table;
        foreach($table->Row as $v){
            $user = (array)($v->Cell[2]->Data);
            $bet = (array)($v->Cell[5]->Data);
            if($user[0] == '会员帐号'){
                continue;
            }else{
                $data[$user[0]] = $bet[0];
            }
        }
        return $data;
    }

    //有效投注列表
    public function effective_bet(){
        $map = $this->getMap();
        $data = Db::name('vip_bet')->where($map)->order('id desc')->paginate();
        return ZBuilder::make('table')
            ->hideCheckbox()
            ->setSearch(['username' => '会员账号']) //设置搜索参数
            ->addColumns([
                ['username','会员账号'],
                ['bet_num','投注量'],
                ['created_at','上传时间']
            ])
            ->setRowList($data) // 设置表格数据
            ->fetch();
    }

/*----------------------------月彩金管理----------------------------------*/
    //月投注列表
    public function week_bet(){
        //上传文件按钮
        $btn_upload = [
            'title' => '文件上传',
            'icon'  => 'fa fa-fw fa-cloud-upload',
            'href'  => url('week_upload')
        ];

        // 导出按钮
        $btn_download = [
            'title' => '导出',
            'icon'  => 'fa fa-fw fa-cloud-download',
            'href'  => url('week_download')
        ];

        //获取月彩金规则
        $rule = [];
        $week = Db::name('week_rule')->field('grade,week_bet,money')->select();
        foreach($week as $v){
            $rule[$v['grade']]['week_bet'] = $v['week_bet'];
            $rule[$v['grade']]['money'] = $v['money'];
        }
        $rule = json_encode($rule);

        $map = $this->getMap();
        $data = Db::table('wns_vip_week')
            ->alias('svw')
            ->join('wns_vip_info svi','svw.username = svi.username')
            ->field('svw.id,svi.bet_anum,svw.username,svw.bet,svw.deposit,svw.create_time,svw.check,svw.update_time')
            ->where($map)
            ->paginate();
        return ZBuilder::make('table')
            ->setTableName('vip_week')
            ->setPageTitle('月投注列表')
            ->setSearch(['wns_vip_week.username' => '会员账号']) // 设置搜索参数
            ->hideCheckbox()
            ->addColumns([
                ['username','会员账号'],
                ['bet_anum','会员等级','callback',function($val){
                    $grade = $this->vip_grade($val);
                    if($grade == 0){
                        return '普通会员';
                    }else{
                        return 'vip_'.$grade;
                    }
                }],
                ['bet','月投注'],
                ['deposit','月存款'],
                ['bet','月彩金','callback',function($k,$val,$rule){
                    $rule = json_decode($rule,1);
                    $grade = $this->vip_grade($val['bet_anum']);
                    $all = $rule[$grade];
                    if($k >= $all['week_bet']){
                        return $all['money'];
                    }else{
                        return $this->money($all['week_bet']);
                    }
                },'__data__',$rule],
                ['create_time','上传时间','datetime','','Y-m-d H:i:s'],
            ])
            ->addTopButton('custom', $btn_upload) // 添加上传按钮
            ->addTopButton('custom',$btn_download)
            ->setRowList($data) // 设置表格数据
            ->fetch();
    }


    //月文件上传
    public function week_upload(){
       if($_POST){
           $result = [];
           if(!input('post.file'))
               $this->error('请上传文件！');
           //上传成功后需要处理的数据
           $path = get_file_path(input('post.file'));
           $data = $this->get_excel($path);
           //清空原有数据
           Db::name('vip_week')->where('1=1')->delete();
           foreach($data as $v){
               $result[] = [
                   'username'    => $v[0],
                   'bet'         => $v[1],
                   'deposit'     => $v[2],
                   'create_time' => time(),
                   'check'       => 0
               ];
           }
           Db::name('vip_week')->insertAll($result);
           $this->success('上传成功','vip/Index/week_bet');
       }else{
           return ZBuilder::make('form')
               ->addFile('file', '文件')
               ->fetch();
       }
    }

    //读取上传excel文档数据
    private function get_excel($file){
        require_once  ROOT_PATH.'public/PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';

        $inputFileName = ROOT_PATH.'public/'.$file;
        date_default_timezone_set('PRC');
        // 读取excel文件
        try {
            $inputFileType = \PHPExcel_IOFactory::identify($inputFileName);
            $objReader = \PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch(Exception $e) {
            die('加载文件发生错误：'.pathinfo($inputFileName,PATHINFO_BASENAME).': '.$e->getMessage());
        }

        // 确定要读取的sheet，什么是sheet，看excel的右下角，真的不懂去百度吧
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();

        $all =  [];
        // 获取一行的数据
        for ($row = 2; $row <= $highestRow; $row++){
            // Read a row of data into an array
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);
            //这里得到的rowData都是一行的数据，得到数据后自行处理，我们这里只打出来看看效果
            $all[] = $rowData['0'];
        }
        return $all;
    }

    //月派彩规则
    public function week_rule(){
        $map = $this->getMap();
        $data = Db::name('week_rule')->where($map)->paginate();
        return ZBuilder::make('table')
            ->hideCheckbox()
            ->addColumns([
                ['grade','等级','callback',function($val){
                    if($val == 0){
                        return '普通会员';
                    }else{
                        return 'vip_'.$val;
                    }
                }],
                ['week_bet','所需月打码量','callback',function($val){
                    if(floatval($val) == 0){
                        $data = 0;
                    }else if(floatval($val) > 0 && floatval($val) < 100000000){
                        $data = (floatval($val)/10000).'万+';
                    }else{
                        $data = (floatval($val)/100000000).'亿+';
                    }
                    return $data;
                }],
                ['money','月彩金'],
                ['create_time','创建时间'],
                ['update_time','更新时间'],
                ['right_button', '操作', 'btn']
            ])
            ->addRightButton('edit', ['href' => url('week_edit', ['id' => '__grade__'])])
            ->setRowList($data) // 设置表格数据
            ->fetch();
    }

    //月规则修改
    public function week_edit($id = ''){
        if($id || $id == 0){
            if($_POST){
                $result = [
                    'week_bet' => input('post.bet'),
                    'money'    => input('post.money'),
                    'update_time' => date('Y-m-d H:i:s')
                ];
                Db::name('week_rule')->where('grade',$id)->update($result);
                $this->success('修改成功','vip/Index/week_rule');
            }else{
                $data = Db::name('week_rule')->where('grade',$id)->find();
                return ZBuilder::make('form')
                    ->addText('bet','所需打码量','',$data['week_bet'])
                    ->addText('money','彩金','',$data['money'])
                    ->fetch();
            }
        }else{
            $this->error('系统错误，请刷新后再试！');
        }
    }

    //导出数据
    public function week_download(){
        //获取月彩金规则
        $rule = [];
        $week = Db::name('week_rule')->field('grade,week_bet,money')->select();
        foreach($week as $v){
            $rule[$v['grade']]['week_bet'] = $v['week_bet'];
            $rule[$v['grade']]['money'] = $v['money'];
        }

        $all = [];
        $data = Db::table('wns_vip_week')
            ->alias('svw')
            ->join('wns_vip_info svi','svw.username = svi.username')
            ->field('svi.bet_anum,svw.username,svw.bet,svw.deposit,svw.create_time')
            ->select();

        foreach($data as $v){
            $all[] = [
                $v['username'],
                $v['bet'],
                $v['deposit'] ,
                $this->vip_grade($v['bet_anum']) == 0?'普通会员':'vip_'.$this->vip_grade($v['bet_anum']),
                $v['bet']>$rule[$this->vip_grade($v['bet_anum'])]['week_bet']?$rule[$this->vip_grade($v['bet_anum'])]['money']:$this->money($v['bet']),
                date('Y/m/d',$v['create_time'])
            ];
        }
        $titlname = ['会员账号','月投注额','月存款','会员等级','彩金','上传时间'];
        $this->exportExcel($titlname,$all,'Sheet1','月彩金列表-'.date('Y-m-d'));
    }

    private function money($k){
        if($k >= 10000 && $k < 30000){
            return 28;
        }else if($k >= 30000 && $k < 100000){
            return 68;
        }else if($k >= 100000 && $k < 200000){
            return 138;
        }else if($k >= 200000 && $k < 500000){
            return 188;
        }else if($k >= 500000 && $k < 800000){
            return 258;
        }else if($k >= 800000 && $k < 1500000){
            return 358;
        }else if($k >= 1500000 && $k < 2000000){
            return 688;
        }else if($k >= 2000000 && $k < 3000000){
            return 1388;
        }else if($k >= 3000000 && $k < 6000000){
            return 5888;
        }else if($k >= 6000000){
            return 10000;
        }else{
            return 0;
        }
    }

    /**
     * 导出excel表格
     *
     * @param   array    $columName    第一行的列名称
     * @param   array    $list         二维数组
     * @param   string   $setTitle    sheet名称
     * @return
     * @author  Tggui <tggui@vip.qq.com>
     */
    function exportExcel($columName, $list, $setTitle='Sheet1', $fileName='demo')
    {
        require_once  ROOT_PATH.'public/PHPExcel-1.8/Classes/PHPExcel.php';
        if ( empty($columName) || empty($list) ) {
            return '列名或者内容不能为空';
        }
        if ( count($list[0]) != count($columName) ) {
            return '列名跟数据的列不一致';
        }
        //实例化PHPExcel类
        $PHPExcel = new \PHPExcel();
        //获得当前sheet对象
        $PHPSheet = $PHPExcel -> getActiveSheet();
        //定义sheet名称
        $PHPSheet -> setTitle($setTitle);

        //excel的列 这么多够用了吧？不够自个加 AA AB AC ……
        $letter = [
            'A','B','C','D','E','F','G','H','I','J','K','L','M',
            'N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
        ];
        //把列名写入第1行 A1 B1 C1 ...
        for ($i=0; $i < count($list[0]); $i++) {
            //$letter[$i]1 = A1 B1 C1  $letter[$i] = 列1 列2 列3
            $PHPSheet->setCellValue("$letter[$i]1","$columName[$i]");
        }
        //内容第2行开始
        foreach ($list as $key => $val) {
            //array_values 把一维数组的键转为0 1 2 3 ..
            foreach (array_values($val) as $key2 => $val2) {
                //$letter[$key2].($key+2) = A2 B2 C2 ……
                $PHPSheet->setCellValue($letter[$key2].($key+2),$val2);
            }
        }
        //生成2007版本的xlsx
        $PHPWriter = \PHPExcel_IOFactory::createWriter($PHPExcel,'Excel2007');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename='.$fileName.'.xlsx');
        header('Cache-Control: max-age=0');
        $PHPWriter->save("php://output");
    }
}