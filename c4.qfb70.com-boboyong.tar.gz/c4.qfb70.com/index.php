
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>正在载入，请稍后</title>
</head>
<body>




<div style="display:none">

<?php



$arr = [

    '0' => [
        'url' => 'https://xs.qfb70.com/chat/index.html?id=200000',
        'cnzz_id' => '1273984654',
    ],
    '1' => [
        'url' => 'https://chat.mqimg.com/dist/standalone.html?eid=162791',
        'cnzz_id' => '1277968540',
    ],
    '2' => [
        'url' => 'http://client.mieiqia.com/?_t='.time(),
        'cnzz_id' => '1274640434',
    ],
    '3' =>[
    	'url' => 'https://e-120865.chatnow.meiqia.com/dist/standalone.html/?_t='.time(),
        'cnzz_id' => '1277439882',
    ]
];

$index = rand(0, 1);

$index = 1;

//同一用户继续上次对话
// $getClientIp = new GetClientIp;
// $ip = $getClientIp->getClientIp();
// $md5Ip = md5($ip);

// $cookieVal = $md5Ip . $index;

// if ($ip) {
//     $flag = $_COOKIE["X_NETBAR_CLIENT_FLAG"];

//     if (strlen($flag) > 1) {

//         $fIp = substr($flag, 0, 32);
//         $i = substr($flag, -1);

//         if ($fIp == $md5Ip) {

//             $index = $i;

//         }
//     } else {
//         setcookie("X_NETBAR_CLIENT_FLAG", $cookieVal, time() + 3600 * 24);
//     }

// }

$r = $arr[$index]['url'];
$cnzz_id = $arr[$index]['cnzz_id'];
echo '<script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id='. $cnzz_id .'&web_id='. $cnzz_id .'"></script>';
if (isset($_SERVER['HTTP_REFERER'])) {
    $refer = $_SERVER['HTTP_REFERER'];
  	$r = $arr[$index]['url'] . '&_r=' . $refer;
    

}

function doCurlPostRequest($url, $requestString, $timeout = 5)
{
    if ($url == '' || $requestString == '' || $timeout <= 0) {
        return '404';
    }
    $con = curl_init((string) $url);
    curl_setopt($con, CURLOPT_HEADER, false);
    curl_setopt($con, CURLOPT_POSTFIELDS, $requestString);
    curl_setopt($con, CURLOPT_POST, true);
    curl_setopt($con, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($con, CURLOPT_TIMEOUT, (int) $timeout);

    $data = curl_exec($con);

    curl_close($con);

    return $data;
}

?>








</div>
<script type="text/javascript">
	setTimeout(function(){
		top.location.href = "<?php echo $r; ?>";
	},800)
</script>

</body>
</html>



