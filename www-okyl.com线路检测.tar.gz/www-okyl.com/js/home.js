
var pi = function () {
    var p = new Ping();
    $('.url').each(function (value, index ) {
        var _this = $(index);
        var url = _this.val();
        p.ping(url,function (err, data) {
            _this.parent().find('.ping').val(data+"ms");
        })
    });
};

$(document).on('click touchstart','.re-check',function () {
    $('.ping').val('00ms');
    pi();
});

$(document).on('click touchstart','.enter',function () {
    href = $(this).data('id');
    window.open(href);
});

pi();