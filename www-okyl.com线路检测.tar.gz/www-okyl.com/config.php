<?php



$title = 'okyl-线路检测';

$copyright = <<<EOF
  <svg
                xmlns="http://www.w3.org/2000/svg"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                width="213px" height="19px">
                <text font-family="Microsoft YaHei" fill="rgb(102, 102, 102)" font-size="18px" x="0px" y="16px">&#169;&#32;&#50;&#48;&#49;&#52;&#32;&#28595;&#23458;&#23089;&#20048;&#29256;&#26435;&#25152;&#26377;</text>
            </svg>
EOF;

$arr=[

'http://ak3019.com',
'http://ak3020.com', 
'http://ak8010.com', 
'http://ak8012.com',
'http://ak8018.com',
'http://ak8028.com',
'http://ak8068.com',
'http://ak8098.com',
'http://ak1828.com',
'http://ak6878.com',


];

$index_arr = array_rand($arr,4) ;

$tmp = [];
foreach($index_arr as $index=>$value){
  array_push($tmp,$arr[$value]);
  
}
$arr = $tmp;


$online = 'https://e-120866.chatnow.meiqia.com/dist/standalone.html';









