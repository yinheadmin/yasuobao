

<?php

include_once('config.php');
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title><?php echo $title;?></title>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css" >
    <link rel="stylesheet" href="css/wap.css">
    <style>

    </style>
</head>
<body class="body-bg-2">
<div class="container-fluid">
    <div  class="logo">
        <img src="images/wap/logo.png" width="50%">
    </div>
    <div class="row center-box">
        <div class="col-sm">
            <div class="main-box">
                <div style="width: 100%;height:6rem;"></div>

<?php
$content = <<<EOF

<div class="row">
    <div class="check">
        <input type="text" value="00ms" disabled title="{url}" class="ping">
        <input type="text" value="{url}" disabled title="{url}" class="url">
        <input type="submit" value="" readonly="readonly" class="enter" data-id="{url}" title="">
    </div>
</div>

EOF;



$str = '';
foreach($arr as $url){

    $str.=str_replace('{url}',$url,$content);
}

echo $str;



?>

                
                <div class="row">
                    <div class="re-check"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row bottom-box">
        <div class="row">

            <div class="warning">
                温馨提示
            </div>

            <div class="suggest">
                建议会员升级DNS，防止部分地区网络运营商篡改网站解析，无法打开官网或弹出其他网站。
                详情请联
                <a class="online" href="<?php echo $online;?>" target="_blank">在线客服</a>

                协助。
            </div>


            <div class="copyright"><?php echo $copyright;?></div>
        </div>

    </div>

</div>


