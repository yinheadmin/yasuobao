<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Telegram;

class telegramBotController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    //
    public function index()
    {
        $response = Telegram::getMe();

        $botId = $response->getId();
        $firstName = $response->getFirstName();
        $username = $response->getUsername();

        echo $botId, $firstName, $username;
    }

    public function sendMsg(Request $request)
    {
        $question = $request->input('question');
        $tel = $request->input('tel');
        $username = $request->input('username');
        $msg = <<<EOF
------datetime------
主人，`username`说:
`question`
号码是：
`tel`
快快撩TA😊
---------------------------
EOF;
        $msg = str_replace('datetime', date("Y-m-d H:i", time()), $msg);
        $msg = str_replace('question', $question, $msg);
        $msg = str_replace('username', $username, $msg);
        $msg = str_replace('tel', $tel, $msg);
        try {
            $response = Telegram::sendMessage([
                'chat_id' => '-323144826',
                'text' => $msg,
                'parse_mode' => 'markdown',
            ]);
            $messageId = $response->getMessageId();
            if ($messageId) {
                return response()->json($this->response(200, 'success', ['msg_id' => $messageId]));
            }

        } catch (\Exception $e) {
            return response()->json($this->response($e->getCode(), $e->getMessage()));
        }

    }

    /**
     *
     * @param int $codeInt
     * @param string $msgStr
     * @param array $restultArr
     * @return array
     */
    private function response($code, $msg, $result = [])
    {
        return $result = array(
            'ret_code' => $code,
            'ret_msg' => $msg,
            'result' => $result,
        );
    }
}
