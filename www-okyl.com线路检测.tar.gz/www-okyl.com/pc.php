
<?php

include_once('config.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo $title;?></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/home-page.css" type="text/css">
</head>
<body>
<div class="container">
    <div class="row top-box"></div>

    <div class="row center-box">

        <div class="main-box">
            <div class="row warp-box"></div>

<?php
$content = <<<EOF

<div class="row">
    <div class="check">
        <input value="00ms" disabled="" title="{url}" class="ok-btn  ping" type="text">
        <input value="{url}" disabled="" title="{url}" class="url" type="text">
        <div class="ok-btn  enter" data-id="{url}">进入网站</div>
    </div>
</div>

EOF;



$str = '';
foreach($arr as $url){

    $str.=str_replace('{url}',$url,$content);
}

echo $str;



?>

           
            
        
            
            <div class="row">
                <div class="col-sm"></div>
                <div class="col-sm">
                    <div class="re-check"></div>
                </div>
                <div class="col-sm"></div>
            </div>
        </div>
    </div>

    <div class="row bottom-box">

        <div class="row">

            <div class="tip1">如以上线路无法正常访问，请尝试以下方式：</div>

            <div class="tip2">使用谷歌浏览器</div>
        </div>

        <div class="row">

            <div class="col-sm-1 chrome"></div>
            <div class="col-sm-11 chrome-tip">具有智能游戏加速、自动切换线路、自动清除记录及在线截图上传等功能，官方指定浏览器。
                谷歌浏览器保证无毒无木马绿色版，部分安全软件会产生误报并影响运行。官方保证，请放心下载。</div>
        </div>


        <div class="row">

            <div class="warning">
                温馨提示
            </div>

            <div class="suggest">
                建议会员升级DNS，防止部分地区网络运营商篡改网站解析，无法打开官网或弹出其他网站。
                详情请联
                <a class="online" href="<?php echo $online;?>" target="_blank">在线客服</a>

                协助。
            </div>


            <div class="copyright"><?php echo $copyright;?></div>
        </div>



    </div>

</div>


