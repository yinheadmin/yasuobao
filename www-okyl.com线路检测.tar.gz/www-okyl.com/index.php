<?php



include_once('function.php');

if (preg_match("/(googlebot|baiduspider|sogou|360spider|bingbot)/i", $_SERVER['HTTP_USER_AGENT'])) {
    echo '
                    <ul id="siteNavPart1">
						<li class="mini_goIndex"><a href="http://www.qq.com/" target="_blank" accesskey="1">腾讯网首页</a></li>
						<li><a href="http://news.qq.com/" target="_blank">新闻</a></li>
						<li><a href="http://finance.qq.com/" target="_blank">财经</a></li>
						<li><a href="http://sports.qq.com/" target="_blank">体育</a></li>
						<li><a href="http://ent.qq.com/" target="_blank">娱乐</a></li>
						<li><a href="http://tech.qq.com/" target="_blank">科技</a></li>
					</ul>
                    </body>
                    </html>


    ';

    return;
}


if(is_mobile_request()){



    include_once('wap.php');



}else{


    include_once('pc.php');


}




?>

<script src="js/jquery.slim.min.js"></script>
<script src="js/ping.min.js"></script>
<script src="js/home.js"></script>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?c6c2c2bf3e84302542c0d772df8064f4";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>


</body>
</html>